let boxes = document.querySelectorAll(".box");
let turnSound = new Audio("turn.mp3");
let msg1 = document.getElementById("msg1");
let msgContainer = document.querySelector(".msg-Con");
let resetBtn = document.getElementById("reset-btn");
let newBtn = document.getElementById("new-btn");


turn = true;
//win patern
winPattern = [
  [0, 1, 2],
  [0, 3, 6],
  [0, 4, 8],
  [1, 4, 7],
  [2, 5, 8],
  [2, 4, 6],
  [3, 4, 5],
  [6, 7, 8]
  
]










boxes.forEach((box)=>{
box.addEventListener("click", ()=>{
  console.log("box was clicked");
  if(turn === true){
   turnSound.play()
   box.innerText = "X";
   document.getElementById("X").style.backgroundColor = "greenyellow";
   document.getElementById("O").style.backgroundColor = "red"
    turn = false;
    
  }else{
    box.innerText = "O";
    turn = true;
    turnSound.play()
    document.getElementById("O").style.backgroundColor = "greenyellow";
    document.getElementById("X").style.backgroundColor = "blue"
  }
  box.disabled = true;
  checkWinner();
})
  
}
);

//enable all boxes

const enableBox = ()=>{
  for (box of boxes){
    box.disabled = false
  }
}


//reset all game function 

const resetGame = ()=>{
  msgContainer.classList.add("hide");
  enableBox();
  for(box of boxes){
    box.innerText = "";
  }
}



resetBtn.addEventListener("click", resetGame);
newBtn.addEventListener("click", resetGame)



//disble all burtons for if win

const disableBtn = ()=>{
  
  for (box of boxes){
    
    box.disabled = true;
    
  }
  
}



// show winner

const showWinner = (winner)=>{
  msg1.innerText = `${winner} WIN THE GAME`
  msgContainer.classList.remove("hide");
 disableBtn();
}

//show draw game 


const showDraw = (winner)=>{
  msg1.innerText = "GAME WAS DRAW"
  msgContainer.classList.remove("hide");
 disableBtn();
}




//check winner
const checkWinner = ()=>{
  
  for ( pattern of winPattern){
    
    let win1 = boxes[pattern[0]].innerText;
    let win2 = boxes[pattern[1]].innerText;
    let win3 = boxes[pattern[2]].innerText;
    
    if(win1 != "" && win2 != "" && win3 != ""){
      if(win1 == win2 && win2 == win3){
        showWinner(win1);
      }
      
    }
  }
}